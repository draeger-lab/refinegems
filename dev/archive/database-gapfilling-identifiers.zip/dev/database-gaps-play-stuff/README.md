# `substance2db` identifier-gap experiment

This folder intentionally keeps all current database-gap testing separate from
the other files in `dev/`.

## Contents

- `combined_substances_df_hr.tsv`: 107-substance scope/input table.
- `fill_missing_substance2db_ids.py`: local-first resolver.
- `migrate_substance2db_primary_key.py`: transactional, idempotent migration
  from the legacy two-column key to the three-column key.
- `test_fill_missing_substance2db_ids.py`: offline unit tests.
- `missing_substance2db_rows.tsv`: application-ready proposed rows.
- `missing_substance2db_rows.audit.tsv`: per-resolver matches and conflicts.
- `missing_substance2db_rows.reviewed.tsv`: manually reviewed source table;
  target-database IDs appended to `evidence` are treated as manual matches.
- `missing_substance2db_rows.missing.tsv`: database identifiers that remain
  missing after all available resolvers.
- `match_missing_vmh_from_sbml.py`: reusable local SBML-to-missing-VMH matcher.
- `vmh-models/Escherichia_coli_KTE9.xml`: largest individual AGORA2 v2.01
  SBML file by VMH's size-sorted directory listing (downloaded from VMH).
- `vmh_largest_model_matches.tsv`: check of the VMH rows still missing after
  the integrated run.

The resolver uses the packaged `bigg_metabolites` table,
`modelseed_compounds.id`, and grouped `modelseed_compounds.aliases`. A local
MetaNetX `chem_xref.tsv` can be added with `--mnx-xref`.

Manually reviewed VMH rows are retained in the reviewed table just like the
other databases. VMH offers a paginated public metabolite API at
`https://www.vmh.life/_api/metabolites/?format=json`. Its records contain the
VMH abbreviation and cross-references including BiGG, KEGG, MetaNetX, SEED,
BioCyc, HMDB, ChEBI, and structural identifiers. This remains a possible
future comprehensive source; the current resolver instead accepts a local VMH
SBML model through `--vmh-sbml`.

## Largest-model VMH experiment

The latest AGORA2 v2.01 individual-reconstruction directory was sorted by file
size. Its first entry, `Escherichia_coli_KTE9.xml`, was downloaded from:

`https://www.vmh.life/files/reconstructions/AGORA2/version2.01/sbml_files/individual_reconstructions/Escherichia_coli_KTE9.xml`

The model contains 3,175 compartment-specific species and 2,067 unique,
compartment-free VMH metabolite IDs. Matching the 52 unresolved VMH rows by
their identifiers.org cross-references produced 42 unambiguous matches, no
conflicts, and 10 entries not found in this model. The report is kept separate
from the reviewed input and does not modify `data.db`.

Inside the complete resolver pipeline, identifiers learned by the earlier
local stages provide one additional VMH match (`crtn` for creatine). The
regenerated proposal table therefore resolves 43 of the 52 VMH gaps. Nine VMH
gaps originally remained. Manual review subsequently resolved six of those
(`cro4`, `glygly`, `Lcystin`, `selmeth`, `selni`, and `adocbl`). The current
outputs therefore leave three VMH gaps and nine database gaps overall. The
standalone match report contains those three remaining VMH rows; none occur in
this model.

## Applied mapping status

The reviewed mapping set has been applied to both
`src/refinegems/data/database/data.db` and its reproducible media schema,
`media_db.sql`. Before the schema migration, mapping application consisted of
301 new rows and 41 legacy `BiGG+VMH` reclassifications (342 changes total).
The proposal file in this folder is retained as that pre-migration application
record. Rerunning the resolver against the updated database is idempotent: it
produces zero proposals and retains the nine unresolved slots.

## Three-column `substance2db` key

The former primary key, `(substance_id, db_id)`, prevented the same textual ID
from belonging to two databases. `substance2db` now uses:

```sql
PRIMARY KEY (substance_id, db_id, db_type)
```

Each database membership is stored as its own row. For example, the previously
blocked water identifier is represented as:

```text
286  WATER  MetaCyc
286  WATER  MetaNetX
```

The migration expanded all 99 stored `BiGG+VMH` rows into separate `BiGG` and
`VMH` memberships, normalized `CHEBI` and the malformed repeated CHEBI value
to `ChEBI`, and added the deferred `WATER | MetaCyc` mapping. The table changed
from 1,058 rows before migration to 1,158 canonical rows afterwards. No stored
`db_type` contains `+`.

Canonical namespaces are defined alongside the other database helpers in
`src/refinegems/utility/databases.py`. Legacy combined labels are accepted
at input boundaries and expanded, but new combined labels are not persisted.
Namespace selection in refineGEMs now uses exact membership rather than
substring matching. MetaCyc is also accepted as an input database column.

The reusable schema generator is in the existing input/output module,
`src/refinegems/utility/io.py`. A newly created database from
`media_db.sql` was compared against all six media tables in `data.db`; there
were zero row differences. SQLite integrity and foreign-key checks passed.

Dry-run the migration on a copy:

```bash
python3 dev/database-gaps-play-stuff/migrate_substance2db_primary_key.py \
  src/refinegems/data/database/data.db \
  --output-database /path/to/migrated-data.db
```

The command is idempotent for an already migrated database. In-place migration
requires an explicit backup path through `--backup`.

Reproduce the local match:

```bash
python3 dev/database-gaps-play-stuff/match_missing_vmh_from_sbml.py \
  dev/database-gaps-play-stuff/missing_substance2db_rows.missing.tsv \
  dev/database-gaps-play-stuff/vmh-models/Escherichia_coli_KTE9.xml \
  dev/database-gaps-play-stuff/vmh_largest_model_matches.tsv
```

## Reproduce the scoped run

From the repository root:

```bash
python3 dev/database-gaps-play-stuff/fill_missing_substance2db_ids.py \
  --scope-table dev/database-gaps-play-stuff/combined_substances_df_hr.tsv \
  --vmh-sbml dev/database-gaps-play-stuff/vmh-models/Escherichia_coli_KTE9.xml \
  --output dev/database-gaps-play-stuff/missing_substance2db_rows.tsv \
  --audit dev/database-gaps-play-stuff/missing_substance2db_rows.audit.tsv \
  --reviewed-missing-input dev/database-gaps-play-stuff/missing_substance2db_rows.reviewed.tsv \
  --missing-output dev/database-gaps-play-stuff/missing_substance2db_rows.missing.tsv
```

The scope table may contain `substance_id`. Otherwise, substances are selected
by an exact unique `name`; `formula` is used only to disambiguate duplicate
names. The packaged `data.db` is not modified.

The command itself remains a dry run and does not modify `data.db`; the applied
status above was performed as an explicit, separately verified database update.

To test application, pass `--output-database /path/to/test-data.db`. The script
copies the packaged database and applies proposals only to the new file. The
copy must use the three-column primary key. Identical textual IDs from distinct
databases are inserted as independent rows; an identical triple is ignored
idempotently.
