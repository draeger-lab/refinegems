#!/usr/bin/env python3
"""Find and optionally apply missing IDs in refineGEMs' ``substance2db``.

The script is a dry run by default. It writes an application-ready TSV of
``(substance_id, db_id, db_type)`` proposals. With ``--output-database`` it
copies the input SQLite database and applies those proposals to the copy; the
packaged source database is never modified.

Mappings come from the local ``bigg_metabolites`` and ``modelseed_compounds``
tables and, optionally, local MetaNetX ``chem_xref.tsv`` and VMH/AGORA SBML
files. No identifiers are sent over the network.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import shutil
import sqlite3
import xml.etree.ElementTree as ET
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Mapping, MutableMapping, Sequence


DB_TYPE_TO_NAMESPACE = {
    "BiGG": "bigg.metabolite",
    "VMH": "vmhmetabolite",
    "KEGG": "kegg.compound",
    "MetaCyc": "metacyc.compound",
    "SEED": "seed.compound",
    "MetaNetX": "metanetx.chemical",
}
NAMESPACE_TO_DB_TYPE = {value: key for key, value in DB_TYPE_TO_NAMESPACE.items()}

LEGACY_COMBINED_DB_TYPES = {"BiGG+VMH": ("BiGG", "VMH")}

BIGG_COLUMNS = {
    "universal_bigg_id": "bigg.metabolite",
    "MetaNetX (MNX) Chemical": "metanetx.chemical",
    "SEED Compound": "seed.compound",
    "KEGG Compound": "kegg.compound",
}

MODELSEED_ALIAS_NAMESPACES = {
    "BiGG": "bigg.metabolite",
    "KEGG": "kegg.compound",
    "MetaCyc": "metacyc.compound",
}

MNX_PREFIXES = {
    "biggM": "bigg.metabolite",
    "bigg.metabolite": "bigg.metabolite",
    "vmhM": "vmhmetabolite",
    "vmhmetabolite": "vmhmetabolite",
    "keggC": "kegg.compound",
    "kegg.compound": "kegg.compound",
    "metacycM": "metacyc.compound",
    "metacyc.compound": "metacyc.compound",
    "seedM": "seed.compound",
    "seed.compound": "seed.compound",
}

REVIEW_PREFIXES = {
    "BiGG": {"BiGG", "bigg.metabolite"},
    "VMH": {"VMH", "vmh", "vmhmetabolite", "vmh.metabolite"},
    "KEGG": {"KEGG", "kegg.compound"},
    "MetaCyc": {"MetaCyc", "metacyc.compound"},
    "SEED": {"SEED", "seed.compound"},
    "MetaNetX": {"MetaNetX", "metanetx.chemical"},
}

REVIEW_ID_PATTERNS = {
    "VMH": re.compile(r"[A-Za-z0-9][A-Za-z0-9_.+\-]*"),
    "KEGG": re.compile(r"C\d{5}"),
    "MetaNetX": re.compile(r"(?:MNXM\d+|WATER)"),
    "SEED": re.compile(r"cpd\d{5}"),
}

RDF_RESOURCE = "{http://www.w3.org/1999/02/22-rdf-syntax-ns#}resource"
VMH_COMPARTMENT_SUFFIX = re.compile(r"__91__[^_]+__93__$")
VMH_RESOURCE_NAMESPACES = {
    "bigg.metabolite": "bigg.metabolite",
    "biocyc": "metacyc.compound",
    "kegg.compound": "kegg.compound",
    "metanetx.chemical": "metanetx.chemical",
    "seed.compound": "seed.compound",
    "vmhmetabolite": "vmhmetabolite",
}


def normalize_name(value: object) -> str:
    """Normalize whitespace and case for conservative exact name matching."""
    return re.sub(r"\s+", " ", str(value or "").strip()).casefold()


def normalize_formula(value: object) -> str:
    """Normalize formula whitespace and case without chemical interpretation."""
    return re.sub(r"\s+", "", str(value or "")).casefold()


def split_values(value: object) -> list[str]:
    """Split comma/semicolon-separated database cells."""
    if value is None:
        return []
    return [
        part.strip()
        for part in re.split(r"\s*[,;]\s*", str(value).strip())
        if part.strip()
    ]


def parse_modelseed_aliases(value: object) -> dict[str, set[str]]:
    """Parse ModelSEED's ``Database: id; id|Database: id`` alias format."""
    aliases: dict[str, set[str]] = defaultdict(set)
    if value is None:
        return {}
    for group in str(value).split("|"):
        database, separator, values = group.partition(":")
        namespace = MODELSEED_ALIAS_NAMESPACES.get(database.strip())
        if not separator or not namespace:
            continue
        identifiers = split_values(values)
        if namespace == "kegg.compound":
            # substance2db's KEGG category currently contains compound IDs
            # (C numbers), not KEGG glycan IDs (G numbers).
            identifiers = [
                identifier
                for identifier in identifiers
                if re.fullmatch(r"C\d{5}", identifier)
            ]
        aliases[namespace].update(identifiers)
    return dict(aliases)


def reviewed_identifiers(row: Mapping[str, object]) -> list[str]:
    """Extract manually added IDs for the missing row's target database."""
    db_type = str(row.get("db_type", ""))
    accepted_prefixes = {
        prefix.casefold() for prefix in REVIEW_PREFIXES.get(db_type, set())
    }
    identifiers = []
    for item in str(row.get("evidence", "") or "").split(";"):
        prefix, separator, identifier = item.partition(":")
        identifier = identifier.strip()
        if (
            separator
            and prefix.strip().casefold() in accepted_prefixes
            and identifier
        ):
            identifiers.append(identifier)
    return sorted(set(identifiers))


def merge_reviewed_missing(
    proposals: list[dict[str, object]],
    audit: list[dict[str, object]],
    path: Path,
    existing_rows: set[tuple[int, str, str]] | None = None,
) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    """Promote manually reviewed IDs and retain confirmed missing entries.

    The reviewed file is authoritative for matching ``substance_id`` and
    ``db_type`` pairs. A target-database ID appended to ``evidence`` resolves
    the row; a row without such an addition remains ``still_missing``.
    """
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        required = {"substance_id", "name", "db_type", "evidence"}
        if not reader.fieldnames or not required <= set(reader.fieldnames):
            raise ValueError(
                f"Reviewed missing table needs columns: {sorted(required)}"
            )
        reviewed_rows = list(reader)

    reviewed_keys = {
        (int(row["substance_id"]), str(row["db_type"])) for row in reviewed_rows
    }
    audit = [
        row
        for row in audit
        if not (
            row.get("status") == "still_missing"
            and (int(row["substance_id"]), str(row.get("db_type", "")))
            in reviewed_keys
        )
    ]
    proposal_keys = {
        (int(row["substance_id"]), str(row["db_id"]), str(row["db_type"]))
        for row in proposals
    }
    proposal_keys.update(existing_rows or set())

    for row in reviewed_rows:
        substance_id = int(row["substance_id"])
        db_type = str(row["db_type"])
        identifiers = reviewed_identifiers(row)
        pattern = REVIEW_ID_PATTERNS.get(db_type)
        invalid = [
            identifier
            for identifier in identifiers
            if pattern and not pattern.fullmatch(identifier)
        ]
        if invalid:
            raise ValueError(
                f"Invalid reviewed {db_type} ID(s) for substance "
                f"{substance_id}: {invalid}"
            )

        if not identifiers:
            audit.append(
                {
                    "substance_id": substance_id,
                    "name": row["name"],
                    "resolver": "manual-review",
                    "status": "still_missing",
                    "db_type": db_type,
                    "evidence": row["evidence"],
                }
            )
            continue

        for identifier in identifiers:
            key = (substance_id, identifier, db_type)
            if key not in proposal_keys:
                proposals.append(
                    {
                        "substance_id": substance_id,
                        "db_id": identifier,
                        "db_type": db_type,
                        "_source": "manual-review",
                    }
                )
                proposal_keys.add(key)
            audit.append(
                {
                    "substance_id": substance_id,
                    "name": row["name"],
                    "resolver": "manual-review",
                    "status": "manual_match",
                    "db_type": db_type,
                    "evidence": f"{db_type}:{identifier}",
                }
            )

    return proposals, audit


@dataclass
class CrossReferenceIndex:
    """A collection of database identifiers grouped by chemical entity."""

    name: str
    entities: MutableMapping[str, MutableMapping[str, set[str]]] = field(
        default_factory=lambda: defaultdict(lambda: defaultdict(set))
    )
    lookup: MutableMapping[tuple[str, str], set[str]] = field(
        default_factory=lambda: defaultdict(set)
    )

    def add(self, entity: str, namespace: str, identifier: str) -> None:
        identifier = identifier.strip()
        if identifier:
            self.entities[entity][namespace].add(identifier)
            self.lookup[(namespace, identifier)].add(entity)

    def resolve(
        self, identifiers: Mapping[str, set[str]]
    ) -> tuple[str, dict[str, set[str]] | None]:
        """Resolve all recognized identifiers to one entity.

        Returns ``matched``, ``unresolved``, or ``conflict``. A conflict is not
        guessed through; that source contributes no proposed rows.
        """
        candidate_sets = []
        for namespace, values in identifiers.items():
            for identifier in values:
                candidates = self.lookup.get((namespace, identifier))
                if candidates:
                    candidate_sets.append(set(candidates))

        if not candidate_sets:
            return "unresolved", None
        candidates = set.intersection(*candidate_sets)
        if len(candidates) != 1:
            return "conflict", None
        entity = next(iter(candidates))
        return "matched", {
            namespace: set(values)
            for namespace, values in self.entities[entity].items()
        }


def connect_read_only(path: Path) -> sqlite3.Connection:
    """Open SQLite without allowing accidental changes."""
    connection = sqlite3.connect(
        f"file:{path.resolve().as_posix()}?mode=ro", uri=True
    )
    connection.row_factory = sqlite3.Row
    return connection


def validate_database(connection: sqlite3.Connection) -> None:
    """Check that the tables needed by this workflow exist."""
    tables = {
        row[0]
        for row in connection.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table'"
        )
    }
    missing = {"substance", "substance2db", "bigg_metabolites"} - tables
    if missing:
        raise ValueError(f"Database is missing required tables: {sorted(missing)}")


def load_substances(
    database: Path,
) -> tuple[dict[int, dict[str, object]], set[tuple[int, str, str]]]:
    """Load substances, their current IDs, and existing unique row keys."""
    substances: dict[int, dict[str, object]] = {}
    existing: set[tuple[int, str, str]] = set()
    with connect_read_only(database) as connection:
        validate_database(connection)
        for row in connection.execute(
            """
            SELECT s.id, s.name, s.formula, x.db_id, x.db_type
            FROM substance AS s
            LEFT JOIN substance2db AS x ON x.substance_id = s.id
            ORDER BY s.id
            """
        ):
            substance_id = int(row["id"])
            substance = substances.setdefault(
                substance_id,
                {
                    "name": row["name"],
                    "formula": row["formula"],
                    "identifiers": defaultdict(set),
                    "existing_db_types": set(),
                },
            )
            db_type = row["db_type"]
            db_id = row["db_id"]
            logical_db_types = LEGACY_COMBINED_DB_TYPES.get(
                str(db_type), (str(db_type),)
            )
            for logical_db_type in logical_db_types:
                namespace = DB_TYPE_TO_NAMESPACE.get(logical_db_type)
                if namespace and db_id:
                    substance["identifiers"][namespace].add(str(db_id))
                    substance["existing_db_types"].add(logical_db_type)
                    existing.add(
                        (substance_id, str(db_id), logical_db_type)
                    )
    return substances, existing


def resolve_scope_table(
    database: Path,
    table: Path,
    delimiter: str = "\t",
    id_column: str = "substance_id",
    name_column: str = "name",
    formula_column: str = "formula",
) -> tuple[set[int], list[dict[str, object]]]:
    """Resolve a TSV/CSV table to a subset of ``substance.id`` values.

    A valid ``substance_id`` wins. Otherwise an exact unique name is used.
    Formula is only used to disambiguate duplicate names, so legacy formula
    differences do not hide an otherwise unique substance.
    """
    by_name: dict[str, list[tuple[int, str]]] = defaultdict(list)
    valid_ids: set[int] = set()
    with connect_read_only(database) as connection:
        validate_database(connection)
        for row in connection.execute("SELECT id, name, formula FROM substance"):
            substance_id = int(row["id"])
            valid_ids.add(substance_id)
            by_name[normalize_name(row["name"])].append(
                (substance_id, normalize_formula(row["formula"]))
            )

    selected: set[int] = set()
    audit: list[dict[str, object]] = []
    with table.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter=delimiter)
        if not reader.fieldnames:
            raise ValueError("Scope table has no header")
        if id_column not in reader.fieldnames and name_column not in reader.fieldnames:
            raise ValueError(
                f"Scope table needs '{id_column}' or '{name_column}' column"
            )

        for row_number, row in enumerate(reader, start=2):
            raw_id = str(row.get(id_column, "") or "").strip()
            if raw_id:
                try:
                    substance_id = int(raw_id)
                except ValueError:
                    substance_id = -1
                if substance_id in valid_ids:
                    selected.add(substance_id)
                    continue
                audit.append(
                    {
                        "substance_id": raw_id,
                        "name": row.get(name_column, ""),
                        "resolver": "scope-table",
                        "status": "unknown_substance_id",
                        "evidence": f"row:{row_number}",
                    }
                )
                continue

            name = row.get(name_column, "")
            candidates = list(by_name.get(normalize_name(name), []))
            if len(candidates) > 1:
                formula = normalize_formula(row.get(formula_column, ""))
                if formula:
                    candidates = [
                        candidate
                        for candidate in candidates
                        if candidate[1] == formula
                    ]
            if len(candidates) == 1:
                selected.add(candidates[0][0])
            else:
                audit.append(
                    {
                        "substance_id": "",
                        "name": name,
                        "resolver": "scope-table",
                        "status": (
                            "ambiguous_scope_match"
                            if candidates
                            else "unresolved_scope_match"
                        ),
                        "evidence": f"row:{row_number}",
                    }
                )
    return selected, audit


def load_bigg_index(database: Path) -> CrossReferenceIndex:
    """Build an index from the packaged ``bigg_metabolites`` table."""
    index = CrossReferenceIndex("bigg_metabolites")
    with connect_read_only(database) as connection:
        validate_database(connection)
        selected = ", ".join(f'"{column}"' for column in BIGG_COLUMNS)
        selected += ', "BioCyc"'
        for row in connection.execute(f"SELECT {selected} FROM bigg_metabolites"):
            bigg_id = row["universal_bigg_id"]
            if not bigg_id:
                continue
            entity = f"bigg:{bigg_id}"
            for column, namespace in BIGG_COLUMNS.items():
                for identifier in split_values(row[column]):
                    index.add(entity, namespace, identifier)
            for biocyc in split_values(row["BioCyc"]):
                source, separator, identifier = biocyc.partition(":")
                if separator and source.upper() == "META":
                    index.add(entity, "metacyc.compound", identifier)
    return index


def load_modelseed_index(database: Path) -> CrossReferenceIndex:
    """Build an index from ModelSEED IDs and their grouped alias field."""
    index = CrossReferenceIndex("modelseed_compounds")
    with connect_read_only(database) as connection:
        tables = {
            row[0]
            for row in connection.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table'"
            )
        }
        if "modelseed_compounds" not in tables:
            return index
        columns = {
            row[1]
            for row in connection.execute("PRAGMA table_info(modelseed_compounds)")
        }
        required = {"id", "aliases"}
        if not required <= columns:
            raise ValueError(
                "modelseed_compounds is missing columns: "
                f"{sorted(required - columns)}"
            )

        for row in connection.execute(
            "SELECT id, aliases FROM modelseed_compounds"
        ):
            modelseed_id = row["id"]
            if not modelseed_id:
                continue
            entity = f"modelseed:{modelseed_id}"
            index.add(entity, "seed.compound", str(modelseed_id))
            for namespace, identifiers in parse_modelseed_aliases(
                row["aliases"]
            ).items():
                for identifier in identifiers:
                    index.add(entity, namespace, identifier)
    return index


def load_metanetx_index(path: Path) -> CrossReferenceIndex:
    """Build an index from MetaNetX ``chem_xref.tsv``."""
    index = CrossReferenceIndex("MetaNetX chem_xref.tsv")
    with path.open("r", encoding="utf-8", newline="") as handle:
        for row in csv.reader(handle, delimiter="\t"):
            if not row or row[0].startswith("#") or len(row) < 2:
                continue
            source, mnx_id = row[0].strip(), row[1].strip()
            if not source or not mnx_id:
                continue
            entity = f"mnx:{mnx_id}"
            index.add(entity, "metanetx.chemical", mnx_id)
            prefix, separator, identifier = source.partition(":")
            namespace = MNX_PREFIXES.get(prefix)
            if separator and namespace:
                index.add(entity, namespace, identifier)
    return index


def parse_identifiers_org_resource(resource: str) -> tuple[str, str] | None:
    """Return an internal namespace and ID from an identifiers.org URI."""
    marker = "identifiers.org/"
    if marker not in resource:
        return None
    namespace_and_id = resource.split(marker, 1)[1]
    namespace, separator, identifier = namespace_and_id.partition("/")
    mapped_namespace = VMH_RESOURCE_NAMESPACES.get(namespace.casefold())
    if (
        not separator
        or not mapped_namespace
        or not identifier
        or identifier.casefold() == "nan"
    ):
        return None
    return mapped_namespace, identifier


def load_vmh_sbml_index(path: Path) -> CrossReferenceIndex:
    """Build a VMH cross-reference index from a local AGORA/VMH SBML model."""
    index = CrossReferenceIndex(f"VMH SBML {path.name}")
    # Published AGORA2 files can contain isolated invalid legacy bytes in
    # names. Replacement decoding preserves identifiers and annotations.
    with path.open(encoding="utf-8", errors="replace") as model_handle:
        for _event, element in ET.iterparse(model_handle, events=("end",)):
            if element.tag.rsplit("}", 1)[-1] != "species":
                continue
            species_id = element.attrib.get("id", "").removeprefix("M_")
            vmh_id = VMH_COMPARTMENT_SUFFIX.sub("", species_id)
            if not vmh_id:
                element.clear()
                continue
            entity = f"vmh:{vmh_id}"
            index.add(entity, "vmhmetabolite", vmh_id)
            for descendant in element.iter():
                resource = descendant.attrib.get(RDF_RESOURCE)
                parsed = (
                    parse_identifiers_org_resource(resource) if resource else None
                )
                if parsed:
                    namespace, identifier = parsed
                    index.add(entity, namespace, identifier)
            element.clear()
    return index


def find_missing_ids(
    database: Path,
    metanetx_xref: Path | None = None,
    vmh_sbml: Path | None = None,
    target_db_types: Iterable[str] = DB_TYPE_TO_NAMESPACE,
    substance_ids: set[int] | None = None,
) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    """Return proposed ``substance2db`` rows and a resolver audit.

    The returned proposals have exactly the three columns used by
    ``substance2db`` and can therefore be inserted without reshaping.
    """
    requested_types = set(target_db_types)
    unknown = requested_types - DB_TYPE_TO_NAMESPACE.keys()
    if unknown:
        raise ValueError(f"Unknown target db_type values: {sorted(unknown)}")

    substances, existing = load_substances(database)
    indexes = [load_bigg_index(database), load_modelseed_index(database)]
    if metanetx_xref:
        indexes.append(load_metanetx_index(metanetx_xref))
    if vmh_sbml:
        indexes.append(load_vmh_sbml_index(vmh_sbml))

    proposals: list[dict[str, object]] = []
    audit: list[dict[str, object]] = []
    for substance_id, substance in substances.items():
        if substance_ids is not None and substance_id not in substance_ids:
            continue
        identifiers = {
            namespace: set(values)
            for namespace, values in substance["identifiers"].items()
        }
        evidence = ";".join(
            f"{namespace}:{identifier}"
            for namespace, values in sorted(identifiers.items())
            for identifier in sorted(values)
        )

        matched_sources = []
        for index in indexes:
            status, found = index.resolve(identifiers)
            audit.append(
                {
                    "substance_id": substance_id,
                    "name": substance["name"],
                    "resolver": index.name,
                    "status": status,
                    "evidence": evidence,
                }
            )
            if found:
                matched_sources.append(index.name)
                for namespace, values in found.items():
                    identifiers.setdefault(namespace, set()).update(values)

        source = "+".join(matched_sources)
        for db_type in sorted(requested_types):
            # "Missing" means that the substance has no row for this database
            # type. Do not turn enrichment into uncontrolled alias expansion.
            type_is_present = db_type in substance["existing_db_types"]
            if type_is_present:
                continue
            namespace = DB_TYPE_TO_NAMESPACE[db_type]
            candidates = sorted(identifiers.get(namespace, set()))
            added_candidate = False
            for identifier in candidates:
                key = (substance_id, identifier, db_type)
                if key in existing:
                    added_candidate = True
                    continue
                proposals.append(
                    {
                        "substance_id": substance_id,
                        "db_id": identifier,
                        "db_type": db_type,
                        "_source": source,
                    }
                )
                existing.add(key)
                added_candidate = True
            if not candidates or not added_candidate:
                audit.append(
                    {
                        "substance_id": substance_id,
                        "name": substance["name"],
                        "resolver": "combined",
                        "status": "still_missing",
                        "db_type": db_type,
                        "evidence": evidence,
                    }
                )

    proposals.sort(
        key=lambda row: (
            str(row["db_type"]).casefold(),
            int(row["substance_id"]),
            str(row["db_id"]).casefold(),
        )
    )
    return proposals, audit


def write_tsv(
    path: Path, rows: Sequence[Mapping[str, object]], headers: Sequence[str]
) -> None:
    """Write rows as TSV."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=headers, delimiter="\t", extrasaction="ignore"
        )
        writer.writeheader()
        writer.writerows(rows)


def apply_to_copy(
    source_database: Path,
    output_database: Path,
    proposals: Sequence[Mapping[str, object]],
) -> None:
    """Copy a database and apply three-column-key proposals transactionally."""
    if output_database.exists():
        raise FileExistsError(
            f"Refusing to overwrite existing output database: {output_database}"
        )
    output_database.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source_database, output_database)
    with sqlite3.connect(output_database) as connection:
        primary_key = [
            row[1]
            for row in sorted(
                connection.execute("PRAGMA table_info(substance2db)"),
                key=lambda row: row[5] or 999,
            )
            if row[5]
        ]
        if primary_key != ["substance_id", "db_id", "db_type"]:
            raise ValueError(
                "substance2db must use PRIMARY KEY "
                "(substance_id, db_id, db_type)"
            )
        connection.executemany(
            """
            INSERT INTO substance2db (substance_id, db_id, db_type)
            VALUES (:substance_id, :db_id, :db_type)
            ON CONFLICT(substance_id, db_id, db_type) DO NOTHING
            """,
            proposals,
        )


def default_database_path() -> Path:
    """Locate refineGEMs' packaged database from the repository layout."""
    for parent in Path(__file__).resolve().parents:
        candidate = (
            parent
            / "src"
            / "refinegems"
            / "data"
            / "database"
            / "data.db"
        )
        if candidate.exists():
            return candidate
    raise FileNotFoundError("Could not locate src/refinegems/data/database/data.db")


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--database", type=Path, default=default_database_path())
    parser.add_argument(
        "--output",
        type=Path,
        required=True,
        help="Application-ready TSV of proposed substance2db rows",
    )
    parser.add_argument("--audit", type=Path, help="Resolver audit TSV")
    parser.add_argument(
        "--missing-output",
        type=Path,
        help="TSV of database identifiers still missing after all resolvers",
    )
    parser.add_argument(
        "--reviewed-missing-input",
        type=Path,
        help="Reviewed missing TSV; target IDs appended to evidence are promoted",
    )
    parser.add_argument("--mnx-xref", type=Path, help="Optional local chem_xref.tsv")
    parser.add_argument(
        "--vmh-sbml",
        type=Path,
        help="Optional local VMH/AGORA SBML model used as a VMH alias source",
    )
    parser.add_argument(
        "--scope-table",
        type=Path,
        help="Limit work to substances named/listed in this TSV or CSV",
    )
    parser.add_argument(
        "--scope-delimiter",
        choices=("tab", "comma"),
        default="tab",
    )
    parser.add_argument("--scope-id-column", default="substance_id")
    parser.add_argument("--scope-name-column", default="name")
    parser.add_argument("--scope-formula-column", default="formula")
    parser.add_argument(
        "--db-type",
        action="append",
        dest="db_types",
        choices=sorted(DB_TYPE_TO_NAMESPACE),
        help="Limit proposals to one or more db_type values",
    )
    parser.add_argument(
        "--output-database",
        type=Path,
        help="Copy the source DB here and apply proposals to the copy",
    )
    args = parser.parse_args(argv)

    scope_ids = None
    scope_audit: list[dict[str, object]] = []
    if args.scope_table:
        scope_ids, scope_audit = resolve_scope_table(
            args.database,
            args.scope_table,
            delimiter="\t" if args.scope_delimiter == "tab" else ",",
            id_column=args.scope_id_column,
            name_column=args.scope_name_column,
            formula_column=args.scope_formula_column,
        )

    proposals, audit = find_missing_ids(
        args.database,
        metanetx_xref=args.mnx_xref,
        vmh_sbml=args.vmh_sbml,
        target_db_types=args.db_types or DB_TYPE_TO_NAMESPACE,
        substance_ids=scope_ids,
    )
    audit = scope_audit + audit
    if args.reviewed_missing_input:
        _, existing_rows = load_substances(args.database)
        proposals, audit = merge_reviewed_missing(
            proposals,
            audit,
            args.reviewed_missing_input,
            existing_rows=existing_rows,
        )
    proposals.sort(
        key=lambda row: (
            str(row["db_type"]).casefold(),
            int(row["substance_id"]),
            str(row["db_id"]).casefold(),
        )
    )
    audit.sort(
        key=lambda row: (
            0 if row.get("db_type") else 1,
            str(row.get("db_type", "")).casefold(),
            str(row.get("name", "")).casefold(),
            int(row["substance_id"]) if str(row.get("substance_id", "")) else -1,
            str(row.get("resolver", "")).casefold(),
            str(row.get("status", "")).casefold(),
        )
    )
    write_tsv(
        args.output,
        proposals,
        ["substance_id", "db_id", "db_type"],
    )
    audit_path = args.audit or args.output.with_suffix(args.output.suffix + ".audit.tsv")
    write_tsv(
        audit_path,
        audit,
        ["substance_id", "name", "resolver", "status", "db_type", "evidence"],
    )
    missing_path = args.missing_output or args.output.with_suffix(
        args.output.suffix + ".missing.tsv"
    )
    still_missing = [
        row for row in audit if row.get("status") == "still_missing"
    ]
    still_missing.sort(
        key=lambda row: (
            str(row.get("db_type", "")).casefold(),
            str(row.get("name", "")).casefold(),
            int(row["substance_id"]),
        )
    )
    write_tsv(
        missing_path,
        still_missing,
        ["substance_id", "name", "db_type", "evidence"],
    )
    if args.output_database:
        apply_to_copy(args.database, args.output_database, proposals)

    summary = defaultdict(int)
    for row in proposals:
        summary[str(row["db_type"])] += 1
    print(
        json.dumps(
            {
                "proposals": len(proposals),
                "scoped_substances": (
                    len(scope_ids) if scope_ids is not None else None
                ),
                "by_db_type": dict(sorted(summary.items())),
                "proposal_file": str(args.output),
                "audit_file": str(audit_path),
                "still_missing": len(still_missing),
                "still_missing_file": str(missing_path),
                "output_database": (
                    str(args.output_database) if args.output_database else None
                ),
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
