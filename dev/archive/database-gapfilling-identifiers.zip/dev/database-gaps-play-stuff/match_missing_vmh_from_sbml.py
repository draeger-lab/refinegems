#!/usr/bin/env python3
"""Match missing VMH aliases against metabolites in a local VMH SBML model.

The script is deliberately independent of a particular model or missing-row table.
It uses identifiers.org annotations as strong cross-reference evidence and only uses
normalized metabolite names when no annotated identifier matches.
"""

from __future__ import annotations

import argparse
import csv
import re
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path


RESOURCE_ATTRIBUTE = "{http://www.w3.org/1999/02/22-rdf-syntax-ns#}resource"
COMPARTMENT_SUFFIX = re.compile(r"__91__[^_]+__93__$")
NON_ALNUM = re.compile(r"[^a-z0-9]+")


def vmh_id_from_species_id(species_id: str) -> str:
    """Convert an AGORA-style species ID to its compartment-free VMH ID."""
    value = species_id.removeprefix("M_")
    return COMPARTMENT_SUFFIX.sub("", value)


def normalized_name(value: str) -> str:
    return NON_ALNUM.sub("", value.casefold())


def parse_resource(resource: str) -> tuple[str, str] | None:
    marker = "identifiers.org/"
    if marker not in resource:
        return None
    namespace_and_id = resource.split(marker, 1)[1]
    if "/" not in namespace_and_id:
        return None
    namespace, identifier = namespace_and_id.split("/", 1)
    if not namespace or not identifier or identifier.casefold() == "nan":
        return None
    return namespace.casefold(), identifier


def read_model(model_path: Path):
    """Return model entries plus indexes over annotations and names."""
    entries: dict[str, dict[str, object]] = {}
    annotation_index: dict[tuple[str, str], set[str]] = defaultdict(set)
    name_index: dict[str, set[str]] = defaultdict(set)
    species_count = 0

    # Some published AGORA2 files contain isolated invalid legacy bytes in names.
    # Replacing those bytes permits XML parsing without changing any identifiers.
    with model_path.open(encoding="utf-8", errors="replace") as model_handle:
        for _event, element in ET.iterparse(model_handle, events=("end",)):
            if element.tag.rsplit("}", 1)[-1] != "species":
                continue
            species_count += 1
            vmh_id = vmh_id_from_species_id(element.attrib["id"])
            entry = entries.setdefault(
                vmh_id,
                {"names": set(), "annotations": set(), "compartments": set()},
            )
            name = element.attrib.get("name", "").strip()
            if name:
                entry["names"].add(name)
                name_index[normalized_name(name)].add(vmh_id)
            compartment = element.attrib.get("compartment", "")
            if compartment:
                entry["compartments"].add(compartment)

            for descendant in element.iter():
                resource = descendant.attrib.get(RESOURCE_ATTRIBUTE)
                parsed = parse_resource(resource) if resource else None
                if parsed:
                    namespace, identifier = parsed
                    entry["annotations"].add((namespace, identifier))
                    annotation_index[(namespace, identifier.casefold())].add(vmh_id)
            element.clear()

    return entries, annotation_index, name_index, species_count


def parse_evidence(value: str) -> list[tuple[str, str]]:
    evidence = []
    for item in value.split(";"):
        if ":" not in item:
            continue
        namespace, identifier = item.split(":", 1)
        if namespace and identifier:
            evidence.append((namespace.casefold(), identifier))
    return evidence


def match_rows(missing_path: Path, model_path: Path, output_path: Path) -> None:
    entries, annotation_index, name_index, species_count = read_model(model_path)

    with missing_path.open(newline="", encoding="utf-8") as handle:
        missing_rows = [
            row
            for row in csv.DictReader(handle, delimiter="\t")
            if row["db_type"].casefold() == "vmh"
        ]

    output_rows = []
    for row in missing_rows:
        evidence_matches: dict[str, set[str]] = defaultdict(set)
        for namespace, identifier in parse_evidence(row.get("evidence", "")):
            for vmh_id in annotation_index.get((namespace, identifier.casefold()), set()):
                evidence_matches[vmh_id].add(f"{namespace}:{identifier}")

        candidates = set(evidence_matches)
        matched_by = "cross_reference"
        if not candidates:
            candidates = name_index.get(normalized_name(row["name"]), set()).copy()
            matched_by = "exact_normalized_name" if candidates else ""

        if not candidates:
            status = "not_found"
        elif len(candidates) == 1:
            status = "matched"
        else:
            status = "conflict"

        candidate_ids = sorted(candidates, key=str.casefold)
        matched_evidence = sorted(
            {item for candidate in candidate_ids for item in evidence_matches[candidate]},
            key=str.casefold,
        )
        model_names = sorted(
            {
                name
                for candidate in candidate_ids
                for name in entries[candidate]["names"]
            },
            key=str.casefold,
        )
        output_rows.append(
            {
                "substance_id": row["substance_id"],
                "name": row["name"],
                "status": status,
                "vmh_ids": ";".join(candidate_ids),
                "matched_by": matched_by,
                "matched_evidence": ";".join(matched_evidence),
                "model_names": ";".join(model_names),
                "input_evidence": row.get("evidence", ""),
            }
        )

    status_order = {"matched": 0, "conflict": 1, "not_found": 2}
    output_rows.sort(
        key=lambda row: (
            status_order[row["status"]],
            row["name"].casefold(),
            int(row["substance_id"]),
        )
    )
    fieldnames = list(output_rows[0]) if output_rows else [
        "substance_id",
        "name",
        "status",
        "vmh_ids",
        "matched_by",
        "matched_evidence",
        "model_names",
        "input_evidence",
    ]
    with output_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter="\t")
        writer.writeheader()
        writer.writerows(output_rows)

    status_counts = defaultdict(int)
    for row in output_rows:
        status_counts[row["status"]] += 1
    print(f"Model: {model_path}")
    print(f"Species: {species_count}; unique compartment-free VMH IDs: {len(entries)}")
    print(f"VMH gaps checked: {len(output_rows)}")
    print(
        "Results: "
        + ", ".join(
            f"{status}={status_counts[status]}"
            for status in ("matched", "conflict", "not_found")
        )
    )
    print(f"Report: {output_path}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("missing", type=Path, help="Missing-alias TSV to examine")
    parser.add_argument("model", type=Path, help="Local VMH/AGORA SBML model")
    parser.add_argument("output", type=Path, help="TSV report to create")
    return parser


if __name__ == "__main__":
    arguments = build_parser().parse_args()
    match_rows(arguments.missing, arguments.model, arguments.output)
