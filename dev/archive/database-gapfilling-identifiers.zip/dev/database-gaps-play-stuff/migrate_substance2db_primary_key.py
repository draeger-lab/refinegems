#!/usr/bin/env python3
"""Migrate ``substance2db`` to one database membership per row.

The target primary key is ``(substance_id, db_id, db_type)``. Legacy combined
types such as ``BiGG+VMH`` are expanded, namespace spelling is canonicalized,
and all unrelated tables are left untouched.
"""

from __future__ import annotations

import argparse
import json
import shutil
import sqlite3
import sys
from pathlib import Path


REPOSITORY_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPOSITORY_ROOT / "src"))

from refinegems.utility.databases import (  # noqa: E402
    DATABASE_NAMESPACES,
    expand_namespace_memberships,
)


TARGET_PRIMARY_KEY = ("substance_id", "db_id", "db_type")


def primary_key_columns(connection: sqlite3.Connection) -> tuple[str, ...]:
    rows = connection.execute("PRAGMA table_info(substance2db)").fetchall()
    return tuple(
        row[1] for row in sorted(rows, key=lambda row: row[5] or 999) if row[5]
    )


def expanded_rows(connection: sqlite3.Connection) -> set[tuple[int, str, str]]:
    rows = set()
    for substance_id, db_id, db_type in connection.execute(
        "SELECT substance_id, db_id, db_type FROM substance2db"
    ):
        for namespace in expand_namespace_memberships(db_type):
            rows.add((int(substance_id), str(db_id), namespace))
    return rows


def migrate_database(database: Path) -> dict[str, object]:
    """Apply the migration transactionally and return its validation summary."""
    connection = sqlite3.connect(database)
    try:
        connection.execute("PRAGMA foreign_keys = ON")
        before_count = connection.execute(
            "SELECT COUNT(*) FROM substance2db"
        ).fetchone()[0]
        old_primary_key = primary_key_columns(connection)
        rows = expanded_rows(connection)

        if old_primary_key == TARGET_PRIMARY_KEY:
            stored_rows = {
                (int(row[0]), str(row[1]), str(row[2]))
                for row in connection.execute(
                    "SELECT substance_id, db_id, db_type FROM substance2db"
                )
            }
            if stored_rows != rows:
                raise ValueError(
                    "Three-column schema contains non-canonical namespace values"
                )
            return {
                "changed": False,
                "before_rows": before_count,
                "after_rows": before_count,
                "expanded_rows": 0,
                "primary_key": list(TARGET_PRIMARY_KEY),
            }

        if old_primary_key != ("substance_id", "db_id"):
            raise ValueError(f"Unexpected existing primary key: {old_primary_key}")

        allowed = ", ".join(f"'{name}'" for name in DATABASE_NAMESPACES)
        connection.execute("PRAGMA foreign_keys = OFF")
        connection.execute("BEGIN IMMEDIATE")
        connection.execute(
            "CREATE TABLE substance2db_new (\n"
            "    substance_id INTEGER NOT NULL,\n"
            "    db_id TEXT NOT NULL,\n"
            f"    db_type TEXT NOT NULL CHECK (db_type IN ({allowed})),\n"
            "    FOREIGN KEY (substance_id) REFERENCES substance(id),\n"
            "    PRIMARY KEY (substance_id, db_id, db_type)\n"
            ")"
        )
        connection.executemany(
            """
            INSERT INTO substance2db_new (substance_id, db_id, db_type)
            VALUES (?, ?, ?)
            """,
            sorted(rows),
        )
        inserted = connection.execute(
            "SELECT COUNT(*) FROM substance2db_new"
        ).fetchone()[0]
        if inserted != len(rows):
            raise RuntimeError(
                f"Migration row-count mismatch: inserted={inserted}, expected={len(rows)}"
            )
        unknown_substances = connection.execute(
            """
            SELECT COUNT(*) FROM substance2db_new AS mapping
            LEFT JOIN substance ON substance.id = mapping.substance_id
            WHERE substance.id IS NULL
            """
        ).fetchone()[0]
        if unknown_substances:
            raise RuntimeError(
                f"Migration found {unknown_substances} unknown substance IDs"
            )
        connection.execute("DROP TABLE substance2db")
        connection.execute("ALTER TABLE substance2db_new RENAME TO substance2db")
        connection.commit()
        connection.execute("PRAGMA foreign_keys = ON")

        integrity = connection.execute("PRAGMA integrity_check").fetchone()[0]
        foreign_key_errors = connection.execute("PRAGMA foreign_key_check").fetchall()
        if integrity != "ok" or foreign_key_errors:
            raise RuntimeError(
                f"Post-migration validation failed: integrity={integrity!r}, "
                f"foreign_keys={foreign_key_errors[:10]!r}"
            )
        return {
            "changed": True,
            "before_rows": before_count,
            "after_rows": len(rows),
            "expanded_rows": len(rows) - before_count,
            "primary_key": list(primary_key_columns(connection)),
        }
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("database", type=Path, help="Source SQLite database")
    target = parser.add_mutually_exclusive_group(required=True)
    target.add_argument(
        "--output-database",
        type=Path,
        help="Copy the source here and migrate the copy",
    )
    target.add_argument(
        "--in-place",
        action="store_true",
        help="Migrate the source database itself",
    )
    parser.add_argument(
        "--backup",
        type=Path,
        help="Required backup destination when using --in-place",
    )
    return parser


def main() -> int:
    arguments = build_parser().parse_args()
    source = arguments.database.resolve()
    if arguments.in_place:
        if not arguments.backup:
            raise ValueError("--in-place requires --backup")
        backup = arguments.backup.resolve()
        if backup.exists():
            raise FileExistsError(f"Refusing to overwrite backup: {backup}")
        with sqlite3.connect(source) as connection:
            backup_connection = sqlite3.connect(backup)
            try:
                connection.backup(backup_connection)
            finally:
                backup_connection.close()
        target = source
    else:
        target = arguments.output_database.resolve()
        if target.exists():
            raise FileExistsError(f"Refusing to overwrite output: {target}")
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)

    summary = migrate_database(target)
    summary["database"] = str(target)
    print(json.dumps(summary, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
