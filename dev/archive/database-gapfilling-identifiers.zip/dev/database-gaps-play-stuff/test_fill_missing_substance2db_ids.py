"""Offline tests for the database-gap identifier experiment."""

from __future__ import annotations

import importlib.util
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path


SCRIPT = Path(__file__).with_name("fill_missing_substance2db_ids.py")
SPEC = importlib.util.spec_from_file_location("fill_missing_substance2db_ids", SCRIPT)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)

MIGRATION_SCRIPT = Path(__file__).with_name(
    "migrate_substance2db_primary_key.py"
)
MIGRATION_SPEC = importlib.util.spec_from_file_location(
    "migrate_substance2db_primary_key", MIGRATION_SCRIPT
)
assert MIGRATION_SPEC and MIGRATION_SPEC.loader
MIGRATION = importlib.util.module_from_spec(MIGRATION_SPEC)
sys.modules[MIGRATION_SPEC.name] = MIGRATION
MIGRATION_SPEC.loader.exec_module(MIGRATION)


def make_database(path: Path) -> None:
    connection = sqlite3.connect(path)
    connection.executescript(
        """
        CREATE TABLE substance (id INTEGER, name TEXT, formula TEXT);
        CREATE TABLE substance2db (
            substance_id INTEGER, db_id TEXT, db_type TEXT,
            PRIMARY KEY (substance_id, db_id, db_type)
        );
        CREATE TABLE bigg_metabolites (
            universal_bigg_id TEXT,
            "MetaNetX (MNX) Chemical" TEXT,
            "SEED Compound" TEXT,
            "KEGG Compound" TEXT,
            BioCyc TEXT
        );
        CREATE TABLE modelseed_compounds (
            id TEXT,
            aliases TEXT
        );
        INSERT INTO substance VALUES (1, 'Glycine', 'C2H5NO2');
        INSERT INTO substance2db VALUES (1, 'MNXM29', 'MetaNetX');
        INSERT INTO substance2db VALUES (1, 'gly', 'BiGG');
        INSERT INTO substance2db VALUES (1, 'legacy-seed-id', 'SEED');
        INSERT INTO bigg_metabolites VALUES (
            'gly', 'MNXM29', 'cpd00033', 'C00037', 'META:GLY'
        );
        INSERT INTO modelseed_compounds VALUES (
            'cpd00033',
            'Name: Glycine; aminoacetic acid|BiGG: gly|'
            || 'KEGG: C00037|MetaCyc: GLY; GLYCINE'
        );
        """
    )
    connection.commit()
    connection.close()


class Substance2dbIdentifierTests(unittest.TestCase):
    def test_primary_key_migration_expands_and_normalizes_legacy_types(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            database = Path(directory) / "legacy.db"
            with sqlite3.connect(database) as connection:
                connection.executescript(
                    """
                    CREATE TABLE substance (
                        id INTEGER PRIMARY KEY, name TEXT, formula TEXT
                    );
                    CREATE TABLE substance2db (
                        substance_id INTEGER,
                        db_id TEXT NOT NULL,
                        db_type TEXT NOT NULL,
                        FOREIGN KEY (substance_id) REFERENCES substance(id),
                        PRIMARY KEY (substance_id, db_id)
                    );
                    INSERT INTO substance VALUES (1, 'Water', 'H2O');
                    INSERT INTO substance2db VALUES (1, 'h2o', 'BiGG+VMH');
                    INSERT INTO substance2db VALUES (
                        1, '15377', 'CHEBI' || char(10) || 'CHEBI'
                    );
                    """
                )

            summary = MIGRATION.migrate_database(database)
            self.assertTrue(summary["changed"])
            self.assertEqual(summary["before_rows"], 2)
            self.assertEqual(summary["after_rows"], 3)
            with sqlite3.connect(database) as connection:
                rows = set(connection.execute("SELECT * FROM substance2db"))
                primary_key = MIGRATION.primary_key_columns(connection)
            self.assertEqual(
                rows,
                {
                    (1, "h2o", "BiGG"),
                    (1, "h2o", "VMH"),
                    (1, "15377", "ChEBI"),
                },
            )
            self.assertEqual(primary_key, MIGRATION.TARGET_PRIMARY_KEY)
            self.assertFalse(MIGRATION.migrate_database(database)["changed"])

    def test_same_identifier_can_belong_to_two_databases(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            database = Path(directory) / "data.db"
            make_database(database)
            with sqlite3.connect(database) as connection:
                connection.execute(
                    'UPDATE bigg_metabolites SET BioCyc = "META:MNXM29"'
                )
                connection.execute(
                    "UPDATE modelseed_compounds SET aliases = 'BiGG: gly'"
                )

            proposals, audit = MODULE.find_missing_ids(database)
            self.assertIn(
                (1, "MNXM29", "MetaCyc"),
                {
                    (row["substance_id"], row["db_id"], row["db_type"])
                    for row in proposals
                },
            )
            self.assertNotIn(
                ("still_missing", "MetaCyc"),
                {(row["status"], row.get("db_type")) for row in audit},
            )

    def test_vmh_sbml_resolves_shared_id_as_separate_membership(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            database = Path(directory) / "data.db"
            output = Path(directory) / "output.db"
            model = Path(directory) / "model.xml"
            make_database(database)
            model.write_text(
                """<?xml version="1.0" encoding="UTF-8"?>
<sbml xmlns="http://www.sbml.org/sbml/level3/version1/core"
      xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
  <model><listOfCompartments><compartment id="c" constant="true"/>
  </listOfCompartments><listOfSpecies>
    <species id="M_gly__91__c__93__" name="Glycine" compartment="c"
             boundaryCondition="false" hasOnlySubstanceUnits="false"
             constant="false">
      <annotation><rdf:RDF><rdf:Description><rdf:Bag>
        <rdf:li rdf:resource="http://identifiers.org/bigg.metabolite/gly"/>
      </rdf:Bag></rdf:Description></rdf:RDF></annotation>
    </species>
  </listOfSpecies></model>
</sbml>
""",
                encoding="utf-8",
            )

            proposals, audit = MODULE.find_missing_ids(
                database, vmh_sbml=model
            )
            triples = {
                (row["substance_id"], row["db_id"], row["db_type"])
                for row in proposals
            }
            self.assertIn((1, "gly", "VMH"), triples)
            self.assertNotIn(
                "VMH",
                {
                    row.get("db_type")
                    for row in audit
                    if row["status"] == "still_missing"
                },
            )

            MODULE.apply_to_copy(database, output, proposals)
            with sqlite3.connect(output) as connection:
                db_types = {
                    row[0]
                    for row in connection.execute(
                        "SELECT db_type FROM substance2db "
                        "WHERE substance_id = 1 AND db_id = 'gly'"
                    )
                }
            self.assertEqual(db_types, {"BiGG", "VMH"})

    def test_missing_report_sort_order(self) -> None:
        rows = [
            {"db_type": "VMH", "name": "Beta", "substance_id": 2},
            {"db_type": "KEGG", "name": "Zulu", "substance_id": 3},
            {"db_type": "KEGG", "name": "Alpha", "substance_id": 1},
        ]
        rows.sort(
            key=lambda row: (
                str(row.get("db_type", "")).casefold(),
                str(row.get("name", "")).casefold(),
                int(row["substance_id"]),
            )
        )
        self.assertEqual(
            [(row["db_type"], row["name"]) for row in rows],
            [("KEGG", "Alpha"), ("KEGG", "Zulu"), ("VMH", "Beta")],
        )

    def test_reviewed_ids_are_promoted_and_deduplicated(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            reviewed = Path(directory) / "reviewed.tsv"
            reviewed.write_text(
                "substance_id\tname\tdb_type\tevidence\n"
                "1\tGlycine\tSEED\tbigg.metabolite:gly;"
                "seed.compound:cpd00033;seed.compound:cpd00033\n"
                "2\tUnknown\tKEGG\tbigg.metabolite:unknown\n"
                "3\tShared\tVMH\tbigg.metabolite:shared;"
                "vmh.metabolite:shared\n",
                encoding="utf-8",
            )
            proposals, audit = MODULE.merge_reviewed_missing(
                [],
                [
                    {
                        "substance_id": 1,
                        "name": "Glycine",
                        "status": "still_missing",
                        "db_type": "SEED",
                    },
                    {
                        "substance_id": 2,
                        "name": "Unknown",
                        "status": "still_missing",
                        "db_type": "KEGG",
                    },
                    {
                        "substance_id": 3,
                        "name": "Shared",
                        "status": "still_missing",
                        "db_type": "VMH",
                    },
                ],
                reviewed,
            )
            self.assertEqual(
                [
                    (row["substance_id"], row["db_id"], row["db_type"])
                    for row in proposals
                ],
                [
                    (1, "cpd00033", "SEED"),
                    (3, "shared", "VMH"),
                ],
            )
            self.assertEqual(
                [row["status"] for row in audit],
                ["manual_match", "still_missing", "manual_match"],
            )

            repeated_proposals, _ = MODULE.merge_reviewed_missing(
                [],
                [],
                reviewed,
                existing_rows={
                    (1, "cpd00033", "SEED"),
                    (3, "shared", "VMH"),
                },
            )
            self.assertEqual(repeated_proposals, [])

    def test_modelseed_alias_parser_respects_database_groups(self) -> None:
        parsed = MODULE.parse_modelseed_aliases(
            "Name: A name; with aliases|BiGG: gly|"
            "KEGG: C00037; C12345|MetaCyc: GLY"
        )
        self.assertEqual(
            parsed,
            {
                "bigg.metabolite": {"gly"},
                "kegg.compound": {"C00037", "C12345"},
                "metacyc.compound": {"GLY"},
            },
        )
        self.assertEqual(
            MODULE.parse_modelseed_aliases("KEGG: C00037; G11113"),
            {"kegg.compound": {"C00037"}},
        )

    def test_proposes_only_missing_rows(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            database = Path(directory) / "data.db"
            make_database(database)
            proposals, audit = MODULE.find_missing_ids(database)
            triples = {
                (row["substance_id"], row["db_id"], row["db_type"])
                for row in proposals
            }
            self.assertEqual(
                triples,
                {
                    (1, "C00037", "KEGG"),
                    (1, "GLY", "MetaCyc"),
                    (1, "GLYCINE", "MetaCyc"),
                },
            )
            missing_types = {
                row["db_type"]
                for row in audit
                if row["status"] == "still_missing"
            }
            self.assertEqual(missing_types, {"VMH"})

    def test_apply_writes_only_to_copy(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "source.db"
            output = Path(directory) / "output.db"
            make_database(source)
            proposals, _ = MODULE.find_missing_ids(source)
            MODULE.apply_to_copy(source, output, proposals)

            with sqlite3.connect(source) as connection:
                source_count = connection.execute(
                    "SELECT COUNT(*) FROM substance2db"
                ).fetchone()[0]
            with sqlite3.connect(output) as connection:
                output_count = connection.execute(
                    "SELECT COUNT(*) FROM substance2db"
                ).fetchone()[0]
            self.assertEqual(source_count, 3)
            self.assertEqual(output_count, 6)

    def test_scope_table_limits_selected_substances(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            database = Path(directory) / "data.db"
            scope = Path(directory) / "scope.tsv"
            make_database(database)
            with sqlite3.connect(database) as connection:
                connection.execute(
                    "INSERT INTO substance VALUES (2, 'Other', 'C1H2')"
                )
            scope.write_text(
                "name\tformula\nGlycine\tC2H5NO2\nUnknown\tX\n",
                encoding="utf-8",
            )

            selected, scope_audit = MODULE.resolve_scope_table(database, scope)
            proposals, _ = MODULE.find_missing_ids(
                database, substance_ids=selected
            )

            self.assertEqual(selected, {1})
            self.assertEqual(
                [row["status"] for row in scope_audit],
                ["unresolved_scope_match"],
            )
            self.assertTrue(proposals)
            self.assertEqual({row["substance_id"] for row in proposals}, {1})


if __name__ == "__main__":
    unittest.main()
